$(function () {

    // $('.ico_close').click(function(){
    // 	$('.speed_up_page').hide();
    // });
})
